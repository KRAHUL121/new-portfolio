package com.kgisl.strnsestock.demostock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemostockApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemostockApplication.class, args);
	}
}
